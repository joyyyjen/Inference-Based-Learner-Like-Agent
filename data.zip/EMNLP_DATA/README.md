### Near-synonym disambiguation and near-synonym example extraction dataset
Description: The training and evaluation dataset used in "Assessing the Helpfulness of Learning Materials with Inference-Based Learner-Like Agent." The dataset is extracted from the Wikipedia sentences for thirty near-synonym pair disambiguation. Each pair has 5000 sentences, and we used the first 4000 as training data and the last 1000 as testing data. The evaluation dataset is annotated by an ESL expert to find the best examples for learners to learn the near-synonym difference. It consists of 600 sentences, 20 sentences for each wordpair, and 10 sentences for each word.


#### Selected Wordpair:
1. opportunity|possibility
2. duty|task
3. task|job
4. duty|job
5. common|ordinary
6. small|little
7. tiny|little
8. previous|former
9. senior|elderly
10. career|job
11. traffic|transportation
12. traffic|transport
13. particular|peculiar
14. briefly|shortly
15. achievement|accomplishment
16. creativity|innovation
17. accountability|responsibility
18. decoration|ornament
19. specific|peculiar
20. special|specific
21. elder|elderly
22. cooperation|collaboration
23. accountability|liability
24. responsibility|liability
25. elder|senior
26. particular|specific
27. commitment|responsibility
28. acknowledge|admit
29. real|authentic
30. delay|postpone

#### Filename and format:

* Near-Synonym Dataset 
We separated the near-synonym dataset into 30 files. Each file is named "WIKI_DATABASE_{wordpair}.json". 
In the file, sentence id and word id is pre-defined in GLOBAL_INDEX.json and word_to_id.json.

* Near-Synonym Example Extraction Evaluation Dataset
The filename is "annotated_evaluation_dataset.tsv".
Column one is wordpair, column two is the raw sentences, and column three is the expert choice.(Y is accpet and N is reject) 

